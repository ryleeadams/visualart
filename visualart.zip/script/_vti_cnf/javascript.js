vti_encoding:SR|utf8-nl
vti_author:SR|NORTHSTARCHARTE\\radams
vti_modifiedby:SR|NORTHSTARCHARTE\\radams
vti_timelastmodified:TR|31 Jan 2019 16:57:39 -0000
vti_timecreated:TR|09 Jan 2019 19:37:05 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|31 Jan 2019 16:52:03 -0000
vti_cacheddtm:TX|31 Jan 2019 16:57:39 -0000
vti_filesize:IR|400
